
consumer_key = 't5AGKRMAP9jxKLiHIBeIOWROx'
consumer_secret = 'j6IWkW3fEN0JkckZty9adylFMEFUsNvlKo2iCU7yX8gbbhoLdf'
access_token = '55853810-LmmIHxxlzD0AAT1sQ4c3mbAbZHXDoNqTyFp2EQQMY'
access_secret = 'ZRh5zEwJ8aID1cunNgkt4vnl18Kh6Q0gd5mZBrMklO8xN'

search=['lufthansa', 'americanair', 'virginamerica', 'southwestair', 'delta', 'klm', 'alaskaair', 'jetblue', 'emirates', 'asianaairlines', 'qatarairways', 'aircanada', 'latamairlinesus', 'etihadairways', 'JetBlue', 'AirAsia', 'flyPAL', 'turkishairlines', 'British_Airways','westjet', 'SingaporeAir', 'cathaypacific', 'EVAAirUS','FlyANA_official', 'iQantas', 'HK_Airlines', 'airfrance', 'taportugal', 'AeromexicoUSA']


search2="americanair, virginamerica, southwestair, delta, klm, alaskaair, jetblue, emirates, asianaairlines, qatarairways, aircanada, latamairlinesus, etihadairways, JetBlue, AirAsia, flyPAL, turkishairlines, British_Airways,westjet, SingaporeAir, cathaypacific, EVAAirUS,FlyANA_official, iQantas, lufthansa, HK_Airlines, airfrance, taportugal, AeromexicoUSA"
